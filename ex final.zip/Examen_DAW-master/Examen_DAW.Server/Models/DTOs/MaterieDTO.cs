﻿namespace Examen_DAW.Server.Models.DTOs
{
    public class MaterieDTO
    {
        public string Name { get; set; }
    }
}
