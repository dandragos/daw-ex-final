﻿namespace Examen_DAW.Server.Models.DTOs
{
    public class ProfesorDTO
    {
        public string Name { get; set; }

        public string Type { get; set; }
    }
}
