﻿namespace Examen_DAW.Server.Models.DTOs
{
    public class ProfesorMaterieDTO
    {
        public Guid ProfesorId { get; set; }
        public Guid MaterieId { get; set; }
    }
}
