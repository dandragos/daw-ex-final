﻿namespace Examen_DAW.Server.Models.Base
{
    public interface IBaseEntity
    {
        Guid Id { get; set; }
    }
}
