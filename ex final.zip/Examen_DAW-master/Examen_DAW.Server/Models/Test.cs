﻿using Examen_DAW.Server.Models.Base;

namespace Examen_DAW.Server.Models
{
    public class Test : BaseEntity
    {
        public string Name { get; set; }
    }
}
