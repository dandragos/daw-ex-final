﻿using Examen_DAW.Server.Models;
using Examen_DAW.Server.Repositories.GenericRepository;

namespace Examen_DAW.Server.Repositories.ProfesorRepository
{
    public interface IProfesorRepository : IGenericRepository<Profesor>
    {
    }
}
