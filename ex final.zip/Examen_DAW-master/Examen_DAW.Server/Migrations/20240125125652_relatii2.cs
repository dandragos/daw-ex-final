﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Examen_DAW.Server.Migrations
{
    /// <inheritdoc />
    public partial class relatii2 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
